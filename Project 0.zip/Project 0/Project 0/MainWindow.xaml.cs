﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Timers; 

namespace Project_0
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 


    public partial class MainWindow : Window
    {

        private static System.Timers.Timer fireTimer;
        private  bool fireColor = true;
        private  bool fireNumber = true;

        public MainWindow()
        {
            InitializeComponent();

            SetTimer();


        }

        public void SetTimer()
        {
            fireTimer = new System.Timers.Timer(1000);

            fireTimer.Elapsed += OnTimedEvent;
            fireTimer.AutoReset = true;
            fireTimer.Enabled = true;

        }

        private  void OnTimedEvent(Object source, ElapsedEventArgs e)
        {

            if (fireNumber && fireColor)
            {
                this.Dispatcher.Invoke(() =>
                {
                    this.RedFire1.Visibility = Visibility.Hidden;
                    this.RedFire2.Visibility = Visibility.Visible;
                    fireNumber = false;
                });



            }

            else if (fireNumber && !fireColor)
            {

                this.Dispatcher.Invoke(() =>
                {

                    this.RedFire1.Visibility = Visibility.Visible;
                    this.RedFire2.Visibility = Visibility.Hidden;
                    fireNumber = false;

                }); 

            }

            else if (!fireNumber && fireColor)
            {

                this.Dispatcher.Invoke(() =>
                {

                    this.YellowFire1.Visibility = Visibility.Hidden;
                    this.YellowFire2.Visibility = Visibility.Visible;
                    fireNumber = true;
                    fireColor = false;
                });
            }
            else
            {

                this.Dispatcher.Invoke(() =>
                {

                    this.YellowFire1.Visibility = Visibility.Visible;
                    this.YellowFire2.Visibility = Visibility.Hidden;
                    fireNumber = true;
                    fireColor = true;

                });
            }
            
            

        }

        private void onClick(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
